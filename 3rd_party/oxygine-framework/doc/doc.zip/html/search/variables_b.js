var searchData=
[
  ['resizable',['resizable',['../structoxygine_1_1core_1_1init__desc.html#a1aabfdba9a957c1c497f9a3e5613e949',1,'oxygine::core::init_desc']]]
];
