var searchData=
[
  ['vsync',['vsync',['../structoxygine_1_1core_1_1init__desc.html#a8316c525bd3d95acc84a43f90603ad16',1,'oxygine::core::init_desc']]]
];
