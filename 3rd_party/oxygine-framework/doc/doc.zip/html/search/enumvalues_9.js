var searchData=
[
  ['zero',['Zero',['../classoxygine_1_1_color.html#a8c4c88878930a889f0a37748cac92c70aaa81ccf16815919f4936dfef0e62682e',1,'oxygine::Color']]]
];
