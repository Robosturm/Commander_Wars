var searchData=
[
  ['borderless',['borderless',['../structoxygine_1_1core_1_1init__desc.html#a745003a208054330b161e1db8a43b733',1,'oxygine::core::init_desc']]]
];
