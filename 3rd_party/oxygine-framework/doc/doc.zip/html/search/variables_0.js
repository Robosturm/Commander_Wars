var searchData=
[
  ['allow_5fscreensaver',['allow_screensaver',['../structoxygine_1_1core_1_1init__desc.html#aa3a8564a39278abf745738fe4002d3bc',1,'oxygine::core::init_desc']]],
  ['allowcomments_5f',['allowComments_',['../class_json_1_1_features.html#a33afd389719624b6bdb23950b3c346c9',1,'Json::Features']]],
  ['allowdroppednullplaceholders_5f',['allowDroppedNullPlaceholders_',['../class_json_1_1_features.html#a5076aa72c05c7596ac339ede36c97a6a',1,'Json::Features']]],
  ['allownumerickeys_5f',['allowNumericKeys_',['../class_json_1_1_features.html#aff3cb16b79d15d3d761b11a0dd6d4d6b',1,'Json::Features']]],
  ['appname',['appName',['../structoxygine_1_1core_1_1init__desc.html#a4750b5fc718c31b7235ae5bb445b4415',1,'oxygine::core::init_desc']]]
];
