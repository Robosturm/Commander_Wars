See the attached screenshot, proving the game runs on Win7.

1. Download and extract Commander Wars (Release Beta_21_4 has been tested)
2. Go to folder with Commander_Wars.exe
3. Drag and drop all the DLLs plus "Commander_Wars.exe.local" file
4. Run the "Enable DLL Redirection.reg" file (this is mandatory)
5. Restart your PC (you must do this to enable DLL redirection) and now you can start Commander_Wars

File origins:
Commander_Wars.exe.local               - This is an empty file, used to indicate DLL redirection. It is mandatory.
api-ms-win-core-synch-l1-2-0.dll       - Custom written by me, source code available https://github.com/vxiiduu/api-ms-win-core-synch-Win7
api-ms-win-core-winrt-error-l1-1-0.dll - Custom written by me (no source code available, can be provided on request)
api-ms-win-core-winrt-error-l1-1-1.dll - Custom written by me (no source code available, can be provided on request)
api-ms-win-core-winrt-l1-1-0.dll       - Custom written by me (no source code available, can be provided on request)
api-ms-win-core-winrt-string-l1-1-0.dll- Custom written by me (no source code available, can be provided on request)
dxgi.dll                               - Custom written by me (no source code available, can be provided on request)
ole32.dll                              - Custom written by me (no source code available, can be provided on request)
dxgi_orig.dll                          - This is the stock Win7SP1 dxgi.dll renamed to dxgi_orig.dll
ole33.dll                              - This is the stock Win7SP1 ole32.dll renamed to ole33.dll
xinput1_4.dll                          - This is the stock Win7SP1 xinput1_3.dll renamed to xinput1_4.dll

Please note: Support for running this software on Win7 is not provided by the original author, it is provided
by me (vxiiduu#4598 on Discord or https://github.com/vxiiduu). Don't bother the original author of the software
since he does not want to support Windows 7.
Please let me know if you find a bug, or if new versions of the game stop running on Windows 7 - I will try to
fix the problem.